<?php
require_once __DIR__ . '/includes/ops_workflow.php';
ops_require_admin();
$pdo = ops_db();
$flash=''; $flashType='ok';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    admin_csrf_verify();
    try {
        if (!ops_table_exists($pdo, 'admin_exceptions')) throw new RuntimeException('admin_exceptions table missing.');
        $action = (string)($_POST['action'] ?? '');
        if ($action === 'save_exception') {
            $id = (int)($_POST['exception_id'] ?? 0);
            $type = trim((string)($_POST['exception_type'] ?? 'general'));
            $severity = trim((string)($_POST['severity'] ?? 'medium'));
            $memberId = (int)($_POST['member_id'] ?? 0);
            $summary = trim((string)($_POST['summary'] ?? ''));
            $details = trim((string)($_POST['details'] ?? ''));
            $status = trim((string)($_POST['status'] ?? 'open'));
            if ($summary === '') throw new RuntimeException('Summary is required.');
            if ($id > 0) {
                $pdo->prepare('UPDATE admin_exceptions SET exception_type=?, severity=?, member_id=?, summary=?, details=?, status=?, resolved_by_admin_id=?, resolved_at=?, updated_at=? WHERE id=?')
                    ->execute([$type, $severity, $memberId ?: null, $summary, $details ?: null, $status, $status === 'resolved' ? ops_admin_id() : null, $status === 'resolved' ? ops_now() : null, ops_now(), $id]);
                $flash='Exception updated.';
            } else {
                $pdo->prepare('INSERT INTO admin_exceptions (exception_type, severity, member_id, summary, details, status, created_by_admin_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
                    ->execute([$type, $severity, $memberId ?: null, $summary, $details ?: null, $status, ops_admin_id(), ops_now(), ops_now()]);
                $flash='Exception created.';
            }
        }
        if ($action === 'refresh_from_system') {
            $items = ops_collect_system_exceptions($pdo);
            foreach ($items as $it) {
                $exists = ops_fetch_one($pdo, 'SELECT id FROM admin_exceptions WHERE status <> ? AND exception_type = ? AND member_id <=> ? AND summary = ? ORDER BY id DESC LIMIT 1', ['resolved', $it['exception_type'], $it['member_id'] ?? null, $it['summary']]);
                if (!$exists) {
                    $pdo->prepare('INSERT INTO admin_exceptions (exception_type, severity, member_id, summary, details, status, created_by_admin_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
                        ->execute([$it['exception_type'], $it['severity'], $it['member_id'] ?? null, $it['summary'], $it['details'] ?? null, 'open', ops_admin_id(), ops_now(), ops_now()]);
                }
            }
            $flash='System exceptions refreshed.';
        }
    } catch (Throwable $e) {
        $flash = $e->getMessage();
        $flashType = 'err';
    }
}
$members = ops_fetch_all($pdo, 'SELECT id, full_name, member_number, email FROM members ORDER BY id DESC LIMIT 200');
$rows = ops_table_exists($pdo, 'admin_exceptions') ? ops_fetch_all($pdo, 'SELECT ae.*, m.full_name, m.member_number FROM admin_exceptions ae LEFT JOIN members m ON m.id = ae.member_id ORDER BY FIELD(ae.status, "open", "in_review", "resolved"), FIELD(ae.severity,"critical","high","medium","low"), ae.id DESC') : [];

$statusItems = [
    ['label' => 'open', 'body' => 'New or unresolved issue. These should be triaged first.'],
    ['label' => 'in_review', 'body' => 'Under investigation. Evidence or operator action is still being gathered.'],
    ['label' => 'resolved', 'body' => 'Closed with a clear outcome and resolution note in the record.'],
    ['label' => 'critical / high severity', 'body' => 'Operational, legal, or ledger-impacting items that should be prioritised.'],
];

ob_start();
ops_admin_help_assets_once();
?>
<style>
.exception-grid{display:grid;grid-template-columns:1.1fr .9fr;gap:18px}
.exception-header{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}
.exception-meta{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-top:16px}
.exception-stat{padding:14px;border-radius:16px;background:rgba(255,255,255,.03);border:1px solid var(--line)}
.exception-stat .k{font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);margin-bottom:6px}
.exception-stat strong{font-size:1.35rem;display:block}
.exception-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
.exception-form-grid .full{grid-column:1/-1}
.field{display:grid;gap:6px}
.field label{font-size:.86rem;color:var(--muted);font-weight:600}
.field input,.field select,.field textarea{width:100%;padding:.85rem 1rem;border-radius:12px;border:1px solid var(--line);background:rgba(255,255,255,.03);color:var(--text)}
.field textarea{min-height:96px;resize:vertical}
@media (max-width:980px){.exception-grid,.exception-meta,.exception-form-grid{grid-template-columns:1fr}}
</style>
<?= ops_admin_info_panel(
    'Stage 7 — Audit, diagnostics, and control review',
    'What this page does',
    'Exceptions is the structured work queue for issues that need human review. Use it to log, triage, investigate, and close operational, compliance, and ledger-related anomalies.',
    [
        'Refresh from system to pull in newly detected issues that the platform can identify automatically.',
        'Use create / update when an operator needs to record a manual issue, escalate severity, or close a resolved item.',
        'Treat this page as the exceptions register, not as the source page where the underlying operational fix is performed.',
    ]
) ?>

<?= ops_admin_workflow_panel(
    'Typical workflow',
    'A clean exception workflow keeps the control plane auditable. The exception is recorded here, but the corrective action usually happens on another page such as Payments, Approvals, Execution, Governance, or Audit.',
    [
        ['title' => 'Identify', 'body' => 'Refresh from system or create a manual exception when an issue is found.'],
        ['title' => 'Triage', 'body' => 'Set severity and status so operators can see what needs urgent action.'],
        ['title' => 'Investigate', 'body' => 'Use the member link and details text to gather evidence and determine the cause.'],
        ['title' => 'Resolve', 'body' => 'Update the record to resolved once the root cause has been addressed on the relevant admin page.'],
    ]
) ?>

<?= ops_admin_guide_panel(
    'How to use this page',
    'This page has two jobs: maintain the live exceptions queue and let operators create or update exception records cleanly.',
    [
        ['title' => 'Exceptions work queue', 'body' => 'Read this top to bottom. Open and critical items are the main operator focus.'],
        ['title' => 'Refresh from system', 'body' => 'Use this to collect new automatically-detected issues without creating duplicates for already-open items.'],
        ['title' => 'Create / update exception', 'body' => 'Use this form for manual issues, status changes, severity escalation, or recording a final resolution.'],
        ['title' => 'Linked member', 'body' => 'Attach a Partner only when the exception is truly about that specific person or account.'],
    ]
) ?>

<?= ops_admin_status_panel(
    'Status guide',
    'These statuses tell operators whether an exception is still waiting for action or has already been closed.',
    $statusItems
) ?>

<div class="card">
  <div class="exception-header">
    <div>
      <h2 style="margin:0">Exceptions work queue<?= ops_admin_help_button('Exceptions work queue', 'This table is the live control register for operational issues that still need attention. Read open and high-severity items first.') ?></h2>
      <p class="muted" style="margin:8px 0 0">Use this register to see what is still open, what is under review, and what has already been resolved.</p>
    </div>
    <form method="post">
      <input type="hidden" name="_csrf" value="<?= ops_h(admin_csrf_token()) ?>">
      <input type="hidden" name="action" value="refresh_from_system">
      <button class="btn-secondary" type="submit">Refresh from system<?= ops_admin_help_button('Refresh from system', 'Pulls in newly detected system exceptions that are not already open. It does not close or change existing exception records.') ?></button>
    </form>
  </div>
  <div class="exception-meta">
    <?php
      $openCount = 0; $reviewCount = 0; $resolvedCount = 0; $criticalCount = 0;
      foreach ($rows as $r) {
          if (($r['status'] ?? '') === 'open') $openCount++;
          if (($r['status'] ?? '') === 'in_review') $reviewCount++;
          if (($r['status'] ?? '') === 'resolved') $resolvedCount++;
          if (in_array(($r['severity'] ?? ''), ['critical','high'], true) && ($r['status'] ?? '') !== 'resolved') $criticalCount++;
      }
    ?>
    <div class="exception-stat"><div class="k">Open exceptions</div><strong><?= (int)$openCount ?></strong></div>
    <div class="exception-stat"><div class="k">In review</div><strong><?= (int)$reviewCount ?></strong></div>
    <div class="exception-stat"><div class="k">Resolved</div><strong><?= (int)$resolvedCount ?></strong></div>
    <div class="exception-stat"><div class="k">Critical / high still open</div><strong><?= (int)$criticalCount ?></strong></div>
  </div>
  <div class="table-wrap" style="margin-top:16px"><table>
    <thead><tr><th>ID</th><th>Type<?= ops_admin_help_button('Exception type', 'The category of issue. Use it to see whether the problem is operational, compliance-related, wallet-related, or another tracked exception class.') ?></th><th>Severity<?= ops_admin_help_button('Severity', 'Severity indicates operator priority. Critical and high items should be addressed before low-risk informational issues.') ?></th><th>Member<?= ops_admin_help_button('Linked member', 'If a specific Partner is affected, the row will show the linked person and their Partner number.') ?></th><th>Summary<?= ops_admin_help_button('Summary and details', 'The summary should state the issue plainly. The details line should explain context, evidence, or what still needs to be checked.') ?></th><th>Status<?= ops_admin_help_button('Exception status', 'Open means unresolved, in_review means actively being investigated, and resolved means the issue has been closed.') ?></th><th>Updated</th></tr></thead>
    <tbody>
    <?php if(!$rows): ?><tr><td colspan="7">No exceptions found.</td></tr><?php endif; ?>
    <?php foreach($rows as $r): ?>
      <tr>
        <td><?= (int)$r['id'] ?></td>
        <td><?= ops_h($r['exception_type']) ?></td>
        <td><?= ops_h($r['severity']) ?></td>
        <td><?= ops_h((string)($r['full_name'] ?? '—')) ?><?php if(!empty($r['member_number'])): ?><div class="muted"><?= ops_h($r['member_number']) ?></div><?php endif; ?></td>
        <td><?= ops_h($r['summary']) ?><div class="muted"><?= ops_h((string)$r['details']) ?></div></td>
        <td><?= ops_h($r['status']) ?></td>
        <td><?= ops_h($r['updated_at']) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
</div>

<div class="card" style="margin-top:18px">
  <h2 style="margin-top:0">Create / update exception<?= ops_admin_help_button('Create / update exception', 'Use this form to add a manual exception, raise or lower severity, change status during investigation, or record the final resolution.') ?></h2>
  <p class="muted">Use this form when a system refresh is not enough or when an operator needs to document and track a manual issue.</p>
  <form method="post" class="stack">
    <input type="hidden" name="_csrf" value="<?= ops_h(admin_csrf_token()) ?>">
    <input type="hidden" name="action" value="save_exception">
    <div class="exception-form-grid">
      <div class="field"><label>Exception ID (leave blank for new)<?= ops_admin_help_button('Exception ID', 'Enter an existing ID only when you intend to update a current exception record. Leave blank to create a new one.') ?></label><input type="number" name="exception_id" min="0"></div>
      <div class="field"><label>Type<?= ops_admin_help_button('Type', 'Choose the best available category so reporting and filtering stay meaningful.') ?></label><select name="exception_type"><?php foreach(ops_exception_types() as $t): ?><option value="<?= ops_h($t) ?>"><?= ops_h($t) ?></option><?php endforeach; ?></select></div>
      <div class="field"><label>Severity<?= ops_admin_help_button('Severity', 'Use severity to show operator urgency, not just technical complexity.') ?></label><select name="severity"><?php foreach(ops_exception_severities() as $s): ?><option value="<?= ops_h($s) ?>"><?= ops_h($s) ?></option><?php endforeach; ?></select></div>
      <div class="field"><label>Status<?= ops_admin_help_button('Status', 'Move to resolved only after the underlying issue has truly been fixed or formally waived.') ?></label><select name="status"><option value="open">open</option><option value="in_review">in_review</option><option value="resolved">resolved</option></select></div>
      <div class="field"><label>Member<?= ops_admin_help_button('Member', 'Attach a Partner when the exception is tied to a specific person, vault, or account path. Leave blank for global/system issues.') ?></label><select name="member_id"><option value="0">— none —</option><?php foreach($members as $m): ?><option value="<?= (int)$m['id'] ?>"><?= ops_h($m['full_name'].' · '.$m['member_number']) ?></option><?php endforeach; ?></select></div>
      <div class="field"><label>Summary<?= ops_admin_help_button('Summary', 'Write the issue in one clear sentence so another operator can understand it immediately.') ?></label><input name="summary"></div>
      <div class="field full"><label>Details<?= ops_admin_help_button('Details', 'Use this for context, evidence, what was checked, and what page or workflow is affected.') ?></label><textarea name="details"></textarea></div>
    </div>
    <div class="actions"><button class="btn" type="submit">Save exception</button></div>
  </form>
</div>
<?php
$body = ob_get_clean();
ops_render_page('Exceptions', 'exceptions', $body, $flash, $flashType);
